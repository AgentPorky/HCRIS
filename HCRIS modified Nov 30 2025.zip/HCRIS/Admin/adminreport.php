<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monthly Consultation Report</title>
     <!-- Bootstrap CSS for styling -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
     <!-- Bootstrap JavaScript bundle for modal and other components -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Font Awesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">
        
    <!-- LINK IN CHART.JS -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Custom CSS Styles -->
     <link rel="stylesheet" href="../css/adminreportstyles.css">
    
</head>
<body>

 <!-- Sidebar for navigation links -->
 <aside>
        <div id="sidenav" class="col-2">
            <ul class="nav nav-pills flex-column mb-auto">
                <!-- Navigation Links -->
                <li class="nav-item">
                    <a href="adminhomepage.php" class="nav-link">
                        <i class="fa-solid fa-hospital me-2"></i>
                        <span class="d-none d-sm-inline text-white">DASHBOARD</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminconsultation.php" class="nav-link">
                        <i class="fa-solid fa-stethoscope me-2"></i>
                        <span class="d-none d-sm-inline text-white">Consultation</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminmedicine.php" class="nav-link">
                        <i class="fa-solid fa-pills me-2"></i>
                        <span class="d-none d-sm-inline text-white">Medicine Inventory</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="healthcare_staff.php" class="nav-link">
                        <i class="fa-solid fa-user-nurse me-2"></i>
                        <span class="d-none d-sm-inline text-white">Healthcare Staff</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminpatientrec.php" class="nav-link">
                        <i class="fa-solid fa-user me-2"></i>
                        <span class="d-none d-sm-inline text-white">Patient Record</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminreport.php" class="nav-link">
                        <i class="fa-solid fa-chart-line me-2"></i>
                        <span class="d-none d-sm-inline text-white">Report</span>
                    </a>
                 <hr>
                </li>
                <li class="nav-item">
                    <a href="adminloginsessions.php" class="nav-link">
                        <i class="fa-solid fa-history me-2"></i>
                        <span class="d-none d-sm-inline text-white">Activity Log</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a id="signOutBtn" class="nav-link">
                        <i class="fa-solid fa-sign-out-alt me-2"></i>
                        <span class="d-none d-sm-inline text-white">Log Out</span>
                    </a>
                </li>

            </ul>
        </div>
    </aside>

    <!-- Header Navigation Bar -->
    <header>
        <nav class="navbar navbar-expand-sm">
            <div class="logo-text-container">
                <img src="../Photos/logo.png" alt="Healthcare Logo" class="logo">
                <p class="logo-text text-white h3">Panghiawan Barangay Healthcare</p>
            </div>
        </nav>
    </header>


    <main>
        <h4 class="text-center">Monthly Total of Consultation and New Patients Report</h4>
        <canvas id="consultationChart" width="400" height="160"></canvas>
    <main>

    <script>
document.addEventListener("DOMContentLoaded", function () {
    function fetchConsultationData() {
        $.ajax({
            url: 'get_consultation_and_patient_data.php', // Updated URL
            method: 'GET',
            dataType: 'json',
            success: function (response) {
                console.log('Response:', response); // Debugging

                if (!response || response.error) {
                    console.error(response.error);
                    return;
                }

                // Map data for consultations and patients for 24 months (2 years)
                const labels = [];
                for (let i = 0; i < 24; i++) {
                    const month = (i % 12) + 1;  // Get the month (1-12)
                    const year = 2024 + Math.floor(i / 12); // Start from 2024 and go to 2025
                    labels.push(`${month}/${year}`);
                }

                const consultationCounts = new Array(24).fill(0);
                response.consultations.forEach(item => {
                    const index = (item.year - 2024) * 12 + item.month - 1;  // Adjust for 2024-2025
                    if (index >= 0 && index < 24) {
                        consultationCounts[index] = item.consultations;
                    }
                });

                const patientCounts = new Array(24).fill(0);
                response.patients.forEach(item => {
                    const index = (item.year - 2024) * 12 + item.month - 1;  // Adjust for 2024-2025
                    if (index >= 0 && index < 24) {
                        patientCounts[index] = item.patients;
                    }
                });

                // Render the chart with both datasets
                renderChart(labels, consultationCounts, patientCounts);
            },
            error: function (xhr, status, error) {
                console.error("Error fetching consultation data:", error);
            }
        });
    }

    function renderChart(labels, consultationData, patientData) {
        const ctx = document.getElementById("consultationChart").getContext("2d");

        new Chart(ctx, {
            type: "line",
            data: {
                labels: labels,
                datasets: [
                    {
                        label: "Number of Consultations",
                        data: consultationData,
                        borderColor: "#1E5128",
                        backgroundColor: "rgba(29, 107, 68, 0.3)",
                        borderWidth: 5,
                        pointBackgroundColor: "#1E5128",
                        pointBorderColor: "#4E9F3D",
                        tension: 0.4,
                    },
                    {
                        label: "Number of Patients",
                        data: patientData,
                        borderColor: "#1E90FF",
                        backgroundColor: "rgba(30, 144, 255, 0.3)",
                        borderWidth: 5,
                        pointBackgroundColor: "#1E90FF",
                        pointBorderColor: "#4169E1",
                        tension: 0.4,
                    },
                ],
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: "top",
                    },
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: "Month/Year",
                        },
                    },
                    y: {
                        beginAtZero: true,
                        min: 0,  // Start the y-axis at 0
                        max: 200,  // End the y-axis at 100
                        title: {
                            display: true,
                            text: "Count",
                        },
                    },
                },
            },
        });
    }

    fetchConsultationData();
});
</script>

</body>
</html>
