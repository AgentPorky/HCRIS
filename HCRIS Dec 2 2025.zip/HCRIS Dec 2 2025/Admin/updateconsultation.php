<?php
require 'db_conn.php';

// Check if the form is submitted with all required data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the data from the form with isset() checks to prevent undefined index errors
    $consultationId = isset($_POST['consultation_id']) ? $_POST['consultation_id'] : null;
    $healthcare_id = isset($_POST['healthcare_id']) ? $_POST['healthcare_id'] : null;
    $patient_id = isset($_POST['patient_id']) ? $_POST['patient_id'] : null;
    $patient_name = isset($_POST['patient_name']) ? $_POST['patient_name'] : null;
    $medicine_id = isset($_POST['medicine_id']) ? $_POST['medicine_id'] : null;
    $medicine_name = isset($_POST['medicine_name']) ? $_POST['medicine_name'] : null;
    $quantity = isset($_POST['quantity']) ? $_POST['quantity'] : null;
    $time = isset($_POST['time']) ? $_POST['time'] : null;
    $date = isset($_POST['date']) ? $_POST['date'] : null;

    // SQL query to fetch the current quantity of medicine from the inventory
    $sqlMedicine = "SELECT medicine_quantity FROM admin_medicine_inventory WHERE medicine_id = ?";
    $stmtMedicine = $conn->prepare($sqlMedicine);
    $stmtMedicine->bind_param("i", $medicine_id); // Use "i" for integer as we're using medicine_id (which is likely an integer)
    $stmtMedicine->execute();
    $resultMedicine = $stmtMedicine->get_result();

    // Check if the medicine exists in the inventory
    if ($resultMedicine && $resultMedicine->num_rows > 0) {
        $rowMedicine = $resultMedicine->fetch_assoc();
        $currentQuantity = $rowMedicine['medicine_quantity'];

        // Check if there is enough medicine in stock
        if ($currentQuantity >= $quantity) {
            // Update the medical record table
            $sqlUpdate = "UPDATE medical_record
                          SET healthcare_id = ?, patient_id = ?, patient_name = ?, medicine_id = ?, medicine_name = ?, quantity = ?, time_ = ?, date_ = ?
                          WHERE consultation_id = ?";
            $stmtUpdate = $conn->prepare($sqlUpdate);
            $stmtUpdate->bind_param("sissssisi", $healthcare_id, $patient_id, $patient_name, $medicine_id, $medicine_name, $quantity, $time, $date, $consultationId);
            
            if ($stmtUpdate->execute()) {
                // Subtract the used quantity from the medicine inventory
                $updatedQuantity = $currentQuantity - $quantity;
                $sqlUpdateInventory = "UPDATE admin_medicine_inventory SET medicine_quantity = ? WHERE medicine_id = ?";
                $stmtUpdateInventory = $conn->prepare($sqlUpdateInventory);
                $stmtUpdateInventory->bind_param("ii", $updatedQuantity, $medicine_id); // Use "ii" for two integers (updatedQuantity and medicine_id)

                if ($stmtUpdateInventory->execute()) {
                    echo "<script>alert('Consultation record updated and inventory adjusted successfully.'); window.location.href='adminconsultation.php';</script>";
                } else {
                    echo "Error updating medicine inventory: " . $stmtUpdateInventory->error;
                }
            } else {
                echo "Error updating consultation record: " . $stmtUpdate->error;
            }
        } else {
            // Not enough medicines in stock
            echo '<script type="text/javascript">
                      alert("Error: Not enough medicines in stock.");
                      window.location = "adminmedicine.php"; 
                  </script>';
            exit();
        }
    } else {
        // Medicine does not exist in the inventory
        echo "Error: Medicine not found in the inventory.";
    }
    $stmtMedicine->close();
} else {
    echo "Invalid request.";
}

// Close the database connection
$conn->close();
?>
