<?php
require 'db_conn.php';

if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error()); // Show the exact error for debugging
}

// Get data from the form using isset to avoid undefined index errors
$consultation_id = $_POST['consultation_id'] ?? null;
$health_id = $_POST['healthcare_id'] ?? null;
$patient_id = $_POST['patient_id'] ?? null;
$patient_name = $_POST['patient_name'] ?? null;
$medicine_id = $_POST['medicine_id'] ?? null;
$medicine_name = $_POST['medicine_name'] ?? null;
$quantity = $_POST['quantity'] ?? null;
$time_ = $_POST['time'] ?? null;
$date_ = $_POST['date'] ?? null;

// Validate that all fields are provided
if (empty($consultation_id) || empty($health_id) || empty($patient_id) || empty($patient_name) || empty($medicine_id) || empty($medicine_name) || empty($quantity) || empty($time_) || empty($date_)) {
    echo "Error: All fields are required.";
    exit();
}

// Check if the consultation ID already exists
$checkConsultationQuery = "SELECT consultation_id FROM medical_record WHERE consultation_id = ?";
$stmtCheck = $conn->prepare($checkConsultationQuery);
if ($stmtCheck === false) {
    die("Error preparing check statement: " . $conn->error);
}
$stmtCheck->bind_param("i", $consultation_id);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();

// If consultation ID exists, show error
if ($resultCheck && $resultCheck->num_rows > 0) {
    echo '
    <script type="text/javascript">
        alert("Error: The consultation ID is already in use. Please provide another ID.");
        window.location = "adminconsultation.php"; // Redirect to the consultation page
    </script>
    ';
    exit();
}

// Check if the medicine exists in the medicine inventory table
$selectMedicineQuery = "SELECT medicine_quantity FROM admin_medicine_inventory WHERE medicine_name = ?";
$stmt = $conn->prepare($selectMedicineQuery);
if ($stmt === false) {
    die("Error preparing select statement: " . $conn->error);
}
$stmt->bind_param("s", $medicine_name);
$stmt->execute();
$resultMedicine = $stmt->get_result();

if ($resultMedicine && $resultMedicine->num_rows > 0) {
    // Medicine exists, proceed with subtraction and insertion

    // Get the current quantity from the medicine table
    $rowMedicine = $resultMedicine->fetch_assoc();
    $currentQuantity = $rowMedicine['medicine_quantity'];

    // Check if there are enough medicines in stock
    if ($currentQuantity >= $quantity) {
        // Perform subtraction in the medicine inventory table
        $updateMedicineQuery = "UPDATE admin_medicine_inventory SET medicine_quantity = medicine_quantity - ? WHERE medicine_name = ?";
        $stmtUpdate = $conn->prepare($updateMedicineQuery);
        if ($stmtUpdate === false) {
            die("Error preparing update statement: " . $conn->error);
        }
        $stmtUpdate->bind_param("is", $quantity, $medicine_name);
        $stmtUpdate->execute();

        if ($stmtUpdate->affected_rows > 0) {
            // Insert data into the consultation table
            $insertConsultationQuery = "INSERT INTO medical_record (consultation_id, healthcare_id, patient_id, patient_name, medicine_id, medicine_name, quantity, time_, date_) 
                                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmtInsert = $conn->prepare($insertConsultationQuery);
            if ($stmtInsert === false) {
                die("Error preparing insert statement: " . $conn->error);
            }
            $stmtInsert->bind_param("iissssiss", $consultation_id, $health_id, $patient_id, $patient_name, $medicine_id, $medicine_name, $quantity, $time_, $date_);
            
            if ($stmtInsert->execute()) {
                echo '
                   <script type="text/javascript">
                      alert("Record saved successfully.");
                      window.location = "adminconsultation.php"; 
                   </script>
                ';
            } else {
                echo "Error: Could not save the consultation record. " . $conn->error;
            }
        } else {
            echo "Error: Could not update medicine inventory. " . $conn->error;
        }
    } else {
        // Not enough medicines in stock
        echo '
        <script type="text/javascript">
           alert("Error: Not enough medicines in stock.");
           window.location = "adminmedicine.php"; 
        </script>
        ';
        exit();
    }
} else {
    // Medicine does not exist in the inventory table
    echo "Error: Medicine not found in the inventory.";
}

$conn->close();
?>
