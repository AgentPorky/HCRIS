<?php

//FOR GRAPH REPORT
require 'db_conn.php'; // Include your database connection file

header('Content-Type: application/json');

// Initialize arrays for consultation and patient data
$consultationData = [];
$patientData = [];

// Query for consultation data grouped by month for two years (24 months)
$consultationQuery = "SELECT MONTH(date_) AS month, YEAR(date_) AS year, COUNT(*) AS consultations 
                      FROM  medical_record
                      WHERE date_ >= CURDATE() - INTERVAL 2 YEAR
                      GROUP BY YEAR(date_), MONTH(date_) 
                      ORDER BY year ASC, month ASC";
$consultationResult = $conn->query($consultationQuery);

if ($consultationResult) {
    while ($row = $consultationResult->fetch_assoc()) {
        $consultationData[] = $row;
    }
}

// Query for patient data grouped by month for two years (24 months)
$patientQuery = "SELECT MONTH(created_at) AS month, YEAR(created_at) AS year, COUNT(*) AS patients 
                 FROM patients 
                 WHERE created_at >= CURDATE() - INTERVAL 2 YEAR
                 GROUP BY YEAR(created_at), MONTH(created_at) 
                 ORDER BY year ASC, month ASC";
$patientResult = $conn->query($patientQuery);

if ($patientResult) {
    while ($row = $patientResult->fetch_assoc()) {
        $patientData[] = $row;
    }
}

// Combine data and send response
$response = [
    'consultations' => $consultationData,
    'patients' => $patientData
];

echo json_encode($response);
?>
