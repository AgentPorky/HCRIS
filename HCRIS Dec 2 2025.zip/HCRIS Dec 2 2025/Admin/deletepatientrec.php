<?php
// DATABASE CONNECTION
require '../Admin/db_conn.php';

if (isset($_POST['ids']) && !empty($_POST['ids'])) {
    $ids = $_POST['ids']; // Array of selected patient_ids

    // Ensure IDs are integers to prevent SQL injection
    $ids = array_map('intval', $ids); // Convert all IDs to integers

    // Prepare the SQL query to delete records
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $sql = "DELETE FROM patients WHERE patient_id IN ($placeholders)";

    // Prepare the statement
    if ($stmt = $conn->prepare($sql)) {
        // Bind parameters dynamically
        $types = str_repeat('i', count($ids)); // 'i' for integers
        $stmt->bind_param($types, ...$ids);

        // Execute the query
        if ($stmt->execute()) {
            echo 'Success';
        } else {
            echo 'Error executing query: ' . $stmt->error;
        }

        $stmt->close();
    } else {
        echo 'Error preparing query: ' . $conn->error;
    }
} else {
    echo 'No IDs provided.';
}

// Close the connection
$conn->close();
?>