<div class="container mt-3">
        <!-- Action Buttons -->
        <div class="mb-3">
            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addConsultationModal">
                Add Consultation
            </button>
            <button id="export-excel" class="btn btn-primary">Download Excel</button>
            <button id="export-pdf" class="btn btn-danger">Download PDF</button>
        </div>

<script>
$(document).ready(function() {
    $('#consultationTable').DataTable();

    $('#export-excel').click(function() {
        const table = document.getElementById('consultationTable');
        const workbook = XLSX.utils.table_to_book(table, { sheet: "Sheet1" });
        XLSX.writeFile(workbook, 'Consultation_Data.xlsx');
    });

    $('#export-pdf').click(function() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        doc.autoTable({
            html: '#consultationTable',
        });
        doc.save('Consultation_Data.pdf');
    });
});
</script>
