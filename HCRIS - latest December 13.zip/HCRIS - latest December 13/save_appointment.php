<?php
session_start();
include 'dbcon.php'; // Include your database connection

$response = ["success" => false, "message" => "Something went wrong."];

// Check if the form is submitted via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the data from the form (sanitized)
    $patient_name = isset($_POST['patient_name']) ? trim($_POST['patient_name']) : '';
    $schedule = isset($_POST['schedule']) ? trim($_POST['schedule']) : '';
    $purpose = isset($_POST['purpose']) ? trim($_POST['purpose']) : '';
    $reason = isset($_POST['reason']) ? trim($_POST['reason']) : '';
    $illness = isset($_POST['illness']) ? trim($_POST['illness']) : '';
    $disease = isset($_POST['disease']) ? trim($_POST['disease']) : '';

    // Validate the data
    if (empty($patient_name) || empty($schedule) || empty($purpose) || empty($reason) || empty($illness)) {
        $response['message'] = "All fields are required!";
        echo json_encode($response);
        exit();
    }

    // Prepare SQL query to insert appointment data into the database
    $stmt = $conn->prepare("INSERT INTO patients_appointment (patient_name, schedule, purpose, reason, t_o_i, disease) VALUES (?, ?, ?, ?, ?, ?)");
    if ($stmt) {
        // Bind parameters and execute query
        $stmt->bind_param("ssssss", $patient_name, $schedule, $purpose, $reason, $illness, $disease);
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = "Appointment booked successfully!";
        } else {
            $response['message'] = "Failed to save appointment: " . $stmt->error; // Improved error message
        }
        $stmt->close();
    } else {
        $response['message'] = "Database query failed: " . $conn->error; // More detailed error
    }

    // Close the database connection
    $conn->close();

    // Send JSON response
    echo json_encode($response);
}
?>
