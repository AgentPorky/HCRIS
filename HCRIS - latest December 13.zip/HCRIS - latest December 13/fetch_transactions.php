<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Database connection details
$host = "localhost";
$dbname = "ths_healthcare";
$username = "root"; // Your database username
$password = ""; // Your database password

$response = ["success" => false, "message" => "", "consultations" => []];

try {
    // Establish database connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Check if patient_id is set in the session
    if (isset($_SESSION['patient_id'])) {
        $patient_id = $_SESSION['patient_id'];
        
        // SQL query to fetch consultations for the logged-in patient
        $query = "
            SELECT 
                `consultation_id`, 
                `patient_id`, 
                `patient_name`, 
                `schedule`, 
                `purpose`, 
                `reason`, 
                `type_of_illness`, 
                `disease`, 
                `medicine_name`, 
                `quantity`, 
                `recommendation`, 
                `status`
            FROM `consultations`
            WHERE `patient_id` = :patient_id
        ";

        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_INT);
        $stmt->execute();

        // Fetch the results
        $consultations = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($consultations) {
            $response['success'] = true;
            $response['consultations'] = $consultations;
        } else {
            $response['message'] = "No consultations found for patient ID " . $patient_id;
        }
    } else {
        $response['message'] = "User not logged in.";
    }
} catch (PDOException $e) {
    $response['message'] = "Database error: " . $e->getMessage();
}

// Ensure the output is in JSON format
header('Content-Type: application/json');
echo json_encode($response);
?>
