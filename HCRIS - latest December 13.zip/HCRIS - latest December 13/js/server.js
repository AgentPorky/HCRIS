const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const fetch = require('node-fetch');

const app = express();
app.use(bodyParser.json());

// iTextmo API credentials
const API_KEY = 'your-api-key'; // Replace with your iTextmo API key
const BASE_URL = 'https://www.itextmo.com/api/send_sms.php'; // iTextmo API URL

// Google reCAPTCHA secret key
const RECAPTCHA_SECRET = '6LdVOZQqAAAAAG9Out6doqz9LwUelQ2qxfKouJHQ'; // Replace with your secret key

let storedOtp = null; // Temporary storage for OTP

// Generate OTP
const generateOtp = () => Math.floor(100000 + Math.random() * 900000).toString();

// Function to verify Google reCAPTCHA
const verifyRecaptcha = async (recaptchaResponse) => {
    const url = `https://www.google.com/recaptcha/api/siteverify?secret=${RECAPTCHA_SECRET}&response=${recaptchaResponse}`;
    const response = await fetch(url, { method: 'POST' });
    const data = await response.json();
    return data.success;
};

// Route to send OTP
app.post('/send-otp', async (req, res) => {
    const { phoneNumber, recaptchaResponse } = req.body;

    // Verify reCAPTCHA
    const isCaptchaValid = await verifyRecaptcha(recaptchaResponse);
    if (!isCaptchaValid) {
        return res.json({ success: false, message: 'reCAPTCHA verification failed' });
    }

    storedOtp = generateOtp();

    try {
        // Send OTP via iTextmo API
        const response = await axios.post(BASE_URL, null, {
            params: {
                apikey: API_KEY,
                to: phoneNumber,
                message: `Your OTP is: ${storedOtp}`,
                sender: 'YourApp', // Sender name
            },
        });

        if (response.data.status === 'success') {
            res.json({ success: true, message: 'OTP sent successfully!' });
        } else {
            res.json({ success: false, message: 'Failed to send OTP' });
        }
    } catch (error) {
        console.error('Error sending OTP:', error);
        res.json({ success: false, message: 'Failed to send OTP' });
    }
});

// Route to verify OTP
app.post('/verify-otp', (req, res) => {
    const { code } = req.body;

    if (code === storedOtp) {
        storedOtp = null; // Clear OTP after verification
        res.json({ success: true, message: 'OTP verification successful!' });
    } else {
        res.json({ success: false, message: 'Invalid OTP' });
    }
});

// Start the server
app.listen(3000, () => console.log('Server running on http://localhost:3000'));
