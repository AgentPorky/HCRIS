-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2024 at 02:34 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ths_healthcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogoutsessions`
--

CREATE TABLE `adminlogoutsessions` (
  `logout_id` int(11) NOT NULL,
  `admin_id` varchar(100) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `logout_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminlogoutsessions`
--

INSERT INTO `adminlogoutsessions` (`logout_id`, `admin_id`, `admin_name`, `logout_time`) VALUES
(1, '21-0916', 'Guiller james c mantala', '2024-12-13 19:37:18'),
(2, '21-0916', 'Guiller james c mantala', '2024-12-13 20:27:24'),
(3, '21-0916', 'Guiller james c mantala', '2024-12-13 20:46:39'),
(4, '21-0916', 'Guiller james c mantala', '2024-12-13 20:46:47');

-- --------------------------------------------------------

--
-- Table structure for table `adminpatient_record`
--

CREATE TABLE `adminpatient_record` (
  `patient_id` varchar(50) NOT NULL,
  `patient_name` varchar(50) NOT NULL,
  `age` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `birthdate` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='DATABASEOF PATIENT''S RECORD';

--
-- Dumping data for table `adminpatient_record`
--

INSERT INTO `adminpatient_record` (`patient_id`, `patient_name`, `age`, `gender`, `birthdate`, `address`) VALUES
('20-2002', 'IAN MIGUEL APOLINAR', '100', 'MALE', '2024-11-05', 'BALINTAWAK'),
('24-1111', 'JESSRHON TOYHORADA', '5', 'MALE', '2024-11-13', 'OMYCCO'),
('24-2222', 'DEV MEMANGS', '23', 'MALE', '2024-11-13', 'BONBON');

-- --------------------------------------------------------

--
-- Table structure for table `admin_healthcare_unit`
--

CREATE TABLE `admin_healthcare_unit` (
  `healthcare_id` varchar(255) NOT NULL,
  `healthcarestaff_name` varchar(50) NOT NULL,
  `position_of_staff` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='ADMIN''S POSITION IN HEALTHCARE';

--
-- Dumping data for table `admin_healthcare_unit`
--

INSERT INTO `admin_healthcare_unit` (`healthcare_id`, `healthcarestaff_name`, `position_of_staff`, `address`) VALUES
('21-0916', 'GUILLER JAMES C MANTALA', 'ADMIN', 'BONBON CATARMAN CAMIGUIN');

-- --------------------------------------------------------

--
-- Table structure for table `admin_loginsessions`
--

CREATE TABLE `admin_loginsessions` (
  `log_id` int(11) NOT NULL,
  `admin_name` varchar(255) NOT NULL,
  `admin_id` varchar(50) NOT NULL,
  `login_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `action_type` enum('login','logout') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_loginsessions`
--

INSERT INTO `admin_loginsessions` (`log_id`, `admin_name`, `admin_id`, `login_time`, `action_type`) VALUES
(1, 'Guiller james c mantala', '21-0916', '2024-12-13 17:11:46', 'login'),
(2, 'Guiller james c mantala', '21-0916', '2024-12-13 17:12:23', 'login'),
(3, 'Guiller james c mantala', '21-0916', '2024-12-13 19:37:24', 'login'),
(4, 'Guiller james c mantala', '21-0916', '2024-12-13 20:27:28', 'login'),
(5, 'Guiller james c mantala', '21-0916', '2024-12-13 20:46:44', 'login'),
(6, 'Guiller james c mantala', '21-0916', '2024-12-13 20:46:53', 'login');

-- --------------------------------------------------------

--
-- Table structure for table `admin_medicine_inventory`
--

CREATE TABLE `admin_medicine_inventory` (
  `medicine_id` varchar(50) NOT NULL,
  `medicine_name` varchar(50) NOT NULL,
  `medicine_quantity` varchar(50) NOT NULL,
  `date_manufactured` varchar(50) NOT NULL,
  `expiration_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='DATABASE OF MEDICINE''S AVAILABILITY';

--
-- Dumping data for table `admin_medicine_inventory`
--

INSERT INTO `admin_medicine_inventory` (`medicine_id`, `medicine_name`, `medicine_quantity`, `date_manufactured`, `expiration_date`) VALUES
('Paracetamol Stock 1', 'PARACETAMOL', '200', '2024-12-12', '2024-12-12');

-- --------------------------------------------------------

--
-- Table structure for table `admin_register`
--

CREATE TABLE `admin_register` (
  `user_id` varchar(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `usertype` enum('User','Admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_register`
--

INSERT INTO `admin_register` (`user_id`, `username`, `password`, `name`, `email`, `usertype`) VALUES
('21-0916', 'ADMINGUILLER', 'c2ea28cb352204b55c5126f572a6d338', 'Guiller james c mantala', 'mantalaguillerjames@gmail', 'Admin'),
('22-2222', 'ADMIN', 'ADMIN', 'ADMIN', 'ADMIN@GMAIL.COM', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `consultations`
--

CREATE TABLE `consultations` (
  `consultation_id` int(255) NOT NULL,
  `healthcare_id` int(255) NOT NULL,
  `patient_id` int(255) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `type_of_illness` varchar(255) NOT NULL,
  `disease` varchar(255) NOT NULL,
  `medicine_name` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `recommendation` varchar(255) NOT NULL,
  `schedule` datetime NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `consultations`
--

INSERT INTO `consultations` (`consultation_id`, `healthcare_id`, `patient_id`, `patient_name`, `purpose`, `reason`, `type_of_illness`, `disease`, `medicine_name`, `quantity`, `recommendation`, `schedule`, `status`) VALUES
(1, 1, 0, 'JAY PABON MAHAYAG', 'Check-up', 'Severe fever', 'N/A', 'N/A', 'Alaxan', '2', '', '2024-12-08 11:02:00', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `medical_record`
--

CREATE TABLE `medical_record` (
  `consultation_id` varchar(50) NOT NULL,
  `healthcare_id` varchar(50) NOT NULL,
  `patient_id` varchar(50) NOT NULL,
  `patient_name` varchar(50) NOT NULL,
  `medicine_id` varchar(50) NOT NULL,
  `medicine_name` varchar(50) NOT NULL,
  `quantity` int(50) NOT NULL,
  `time_` varchar(50) NOT NULL,
  `date_` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patient_id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `birthday` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `Social_stat` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `otps` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_id`, `fullname`, `birthday`, `age`, `address`, `Social_stat`, `gender`, `username`, `password`, `otps`) VALUES
(5, 'Jessrhon C. Toyhoroda', '2024-12-13', '22', 'OMYCCO', 'single', 'male', '123456', '$2y$10$XuooTjYr5TlApzv7k4vIVuJ8Qta3KT8EtMq5JJLb3ia0xN.6KU0FK', '');

-- --------------------------------------------------------

--
-- Table structure for table `patients_appointment`
--

CREATE TABLE `patients_appointment` (
  `appointment_id` int(255) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `schedule` datetime NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `t_o_i` varchar(255) NOT NULL,
  `disease` varchar(255) NOT NULL,
  `medicine_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients_appointment`
--

INSERT INTO `patients_appointment` (`appointment_id`, `patient_id`, `patient_name`, `schedule`, `purpose`, `reason`, `t_o_i`, `disease`, `medicine_id`) VALUES
(1, 0, 'JAY PABON MAHAYAG', '2024-12-07 11:11:00', 'dfdfd', 'dfdf', 'dfdf', 'dfdf', 0),
(2, 0, 'JAY PABON MAHAYAG', '2024-12-20 13:04:00', 'Check-up', 'sdsd', 'sdsd', 'sdsd', 0),
(3, 0, 'JAY PABON MAHAYAG', '2024-12-12 00:00:00', 'TESTING', 'TESTING', 'TESTING', 'TESTING', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogoutsessions`
--
ALTER TABLE `adminlogoutsessions`
  ADD PRIMARY KEY (`logout_id`);

--
-- Indexes for table `admin_healthcare_unit`
--
ALTER TABLE `admin_healthcare_unit`
  ADD PRIMARY KEY (`healthcare_id`);

--
-- Indexes for table `admin_loginsessions`
--
ALTER TABLE `admin_loginsessions`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `admin_register`
--
ALTER TABLE `admin_register`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `consultations`
--
ALTER TABLE `consultations`
  ADD PRIMARY KEY (`consultation_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `patients_appointment`
--
ALTER TABLE `patients_appointment`
  ADD PRIMARY KEY (`appointment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminlogoutsessions`
--
ALTER TABLE `adminlogoutsessions`
  MODIFY `logout_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `admin_loginsessions`
--
ALTER TABLE `admin_loginsessions`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `consultations`
--
ALTER TABLE `consultations`
  MODIFY `consultation_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `patients_appointment`
--
ALTER TABLE `patients_appointment`
  MODIFY `appointment_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
