<?php
// verify_otp.php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $otp = $input['otp'];

    $sid = 'AC11589a1063ae2c57285efe050219acbf'; // Twilio SID
    $token = '9ef6e7231216857eefab85adbe985540'; // Twilio Auth Token
    $serviceSid = 'VA6b7350a52d39b56ea1b3b2bcbf37ed9d'; // Twilio Verify Service SID

    // Initialize cURL
    $ch = curl_init('https://verify.twilio.com/v2/Services/'.$serviceSid.'/VerificationCheck');

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, [
        'To' => '+639099087571', // This should be the user's phone number
        'Code' => $otp
    ]);
    curl_setopt($ch, CURLOPT_USERPWD, $sid . ':' . $token);

    $response = curl_exec($ch);
    curl_close($ch);

    // Assuming response is JSON
    $response_data = json_decode($response, true);

    if ($response_data && isset($response_data['status']) && $response_data['status'] === 'approved') {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
}
?>


