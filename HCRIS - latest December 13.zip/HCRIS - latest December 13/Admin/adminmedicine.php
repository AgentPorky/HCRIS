<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN_MEDICINE</title>
    
    <!-- Bootstrap CSS for styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    
    <!-- Custom CSS file for additional styles -->
    <link rel="stylesheet" href="../Css/adminmedicinestyless.css">

    <!-- jQuery and DataTables JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <!-- Bootstrap JavaScript bundle for modal and other components -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- SheetJS Library for Excel Export -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

    <!-- jsPDF Library for PDF Export -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

    <!-- jsPDF AutoTable Plugin -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>


</head>
<body class="container-liquid">
    <!-- Sidebar for navigation links -->
    <aside>
        <div id="sidenav" class="col-2">
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="adminhomepage.php" class="nav-link">
                        <i class="fa-solid fa-hospital me-2"></i>
                        <span class="d-none d-sm-inline text-white">DASHBOARD</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminconsultation.php" class="nav-link">
                        <i class="fa-solid fa-stethoscope me-2"></i>
                        <span class="d-none d-sm-inline text-white">Consultation</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="Appointments.php" class="nav-link">
                        <i class="fa-solid fa-users me-2"></i>
                        <span class="d-none d-sm-inline text-white">Appointments</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminmedicine.php" class="nav-link">
                        <i class="fa-solid fa-pills me-2"></i>
                        <span class="d-none d-sm-inline text-white">Medicine Inventory</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="healthcare_staff.php" class="nav-link">
                        <i class="fa-solid fa-user-nurse me-2"></i>
                        <span class="d-none d-sm-inline text-white">Healthcare Staff</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminpatientrec.php" class="nav-link">
                        <i class="fa-solid fa-user me-2"></i>
                        <span class="d-none d-sm-inline text-white">Patient Record</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminreport.php" class="nav-link">
                        <i class="fa-solid fa-chart-line me-2"></i>
                        <span class="d-none d-sm-inline text-white">Report</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminloginsessions.php" class="nav-link">
                        <i class="fa-solid fa-history me-2"></i>
                        <span class="d-none d-sm-inline text-white">Activity Log</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a id="signOutBtn" class="nav-link">
                        <i class="fa-solid fa-sign-out-alt me-2"></i>
                        <span class="d-none d-sm-inline text-white">Log Out</span>
                    </a>
                </li>
            </ul>
        </div>
    </aside>

    
    <!-- Header section with site title -->
    <header>
        <nav class="navbar navbar-expand-sm">
            <div class="logo-text-container">
                <img src="../Photos/logo.png" alt="Healthcare Logo" class="logo">
                <p class="logo-text text-white h3">Panghiawan Barangay Healthcare</p>
            </div>
        </nav>
    </header>

    <main>
        <!-- Modal for Adding Medicine -->
        <div class="modal" id="addMedicineModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">ADD MEDICINE</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form id="medicineForm" action="adminmedicine_process.php" method="post">
                            <div class="form-group">
                                <label for="medicine_id">Medicine Id:</label>
                                <input type="text" class="form-control" id="medicine_id" name="medicine_id" placeholder="Enter medicine ID" required>
                            </div>
                            <div class="form-group">
                                <label for="medicine_name">Medicine Name:</label>
                                <input type="text" class="form-control" id="medicine_name" name="medicine_name" placeholder="Enter medicine name" required>
                            </div>
                            <div class="form-group">
                                <label for="medicine_quantity">Medicine Quantity:</label>
                                <input type="number" class="form-control" id="medicine_quantity" name="medicine_quantity" placeholder="Enter quantity" min="1" required>
                            </div>
                            <div class="form-group">
                                <label for="date_manufactured">Date Manufactured:</label>
                                <input type="date" class="form-control" id="date_manufactured" name="date_manufactured" required>
                            </div>
                            <div class="form-group">
                                <label for="expiration_date">Expiration Date:</label>
                                <input type="date" class="form-control" id="expiration_date" name="expiration_date" required>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success" form="medicineForm">SAVE</button>
                        <button type="reset" class="btn btn-info" form="medicineForm">RESET</button>
                        <button type="button" class="btn btn-warning" data-bs-dismiss="modal">CLOSE</button>
                    </div>
                </div>
            </div>
        </div>
         <!-- Button to open the Consultation Modal -->
         <div class="container bg-light d-flex ">
                <button id="delete-selected" class="btn btn-danger mx-5">Delete Selected</button> 
                <button type="button" class="btn btn-success me-2" data-bs-toggle="modal" data-bs-target="#addMedicineModal">Click to add medicine</button>
                <button id="export-excel" class="btn btn-success me-2">Download As Excel</button>
                <button id="export-pdf" class="btn btn-success me-2">Download As PDF</button>
            </div>
       
        <!-- Medicine Inventory Table -->
        <div class="table-container table-responsive text-center">
            <?php
            require 'db_conn.php';

            if (!$conn) {
                echo "<div class='alert alert-danger'>Connection failed!</div>";
                exit();
            }

            $sql = "SELECT * FROM admin_medicine_inventory";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<table id='medicineTable' class='display table table-striped table-hover table-bordered mx-auto' style='width: 80%;'>
                      <thead>
                            <tr>
                                <th>Select</th>
                                <th>Medicine ID</th>
                                <th>Medicine Name</th>
                                <th>Quantity</th>
                                <th>Date Manufactured</th>
                                <th>Expiration Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td><input type='checkbox' class='row-checkbox'></td> <!-- Individual row checkbox -->
                            <td>{$row['medicine_id']}</td>
                            <td>{$row['medicine_name']}</td>
                            <td>{$row['medicine_quantity']}</td>
                            <td>{$row['date_manufactured']}</td>
                            <td>{$row['expiration_date']}</td>
                            <td>
                                <div class='d-flex justify-content-between'>
                                    <button class='btn btn-success btn-sm me-2' onclick=\"window.location.href='editmedicineinv.php?medicineId={$row['medicine_id']}'\">
                                        Edit
                                    </button>
                                </div>
                            </td>
                          </tr>";
                }
                echo "</tbody></table>";
            } else {
                echo "<div class='alert alert-warning'>No records found.</div>";
            }

            $conn->close();
            ?>
        </div>
    </main>

    <!-- Initialize DataTables for the medicine table -->
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        $('#medicineTable').DataTable({
            "paging": true,
            "searching": true,
            "ordering": true,
            "pageLength": 10,
            "lengthMenu": [5, 10, 25, 50, 100, 500, 900 ]
        });
    });

    // Delete Selected Medicines
    document.getElementById('delete-selected').addEventListener('click', function () {
        const selectedCheckboxes = document.querySelectorAll('.row-checkbox:checked');
        const selectedIds = Array.from(selectedCheckboxes).map(checkbox => checkbox.closest('tr').cells[1].textContent); // Get Medicine IDs
        
        if (selectedIds.length === 0) {
            Swal.fire('Please select at least one medicine.');
            return;
        }
        
        Swal.fire({
            title: 'Are you sure?',
            text: 'This action will permanently delete selected medicines.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete',
            cancelButtonText: 'No, cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch('deletemedicineinv.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ medicine_ids: selectedIds }) // Send selected IDs for deletion
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire('Deleted!', 'The selected medicines have been deleted.', 'success');
                        location.reload(); // Reload the page to reflect changes
                    } else {
                        Swal.fire('Error!', data.error || 'There was a problem deleting the medicines.', 'error');
                    }
                })
                .catch(error => Swal.fire('Error!', 'An unexpected error occurred.', 'error'));
            }
        });
    });
</script>

</body>
</html>
