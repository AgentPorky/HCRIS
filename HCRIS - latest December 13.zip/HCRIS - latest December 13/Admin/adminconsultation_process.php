<?php
require 'db_conn.php';

// Check if the connection is successful
if (!$conn) {
    error_log("Connection failed: " . mysqli_connect_error());
    die('Connection failed: ' . mysqli_connect_error());
}

// Debugging: Log the received POST data
error_log(print_r($_POST, true));

// Retrieve form data
$health_id = $_POST['healthcare_id'] ?? null;
$patient_name = $_POST['patient_name'] ?? null;
$medicine_id = $_POST['medicine_id'] ?? null;
$quantity = $_POST['quantity'] ?? null;
$purpose = $_POST['purpose'] ?? null;
$reason = $_POST['reason'] ?? null;
$type_of_illness = $_POST['type_of_illness'] ?? null;
$disease = $_POST['disease'] ?? null;
$schedule = $_POST['schedule'] ?? null;
$recommendation = $_POST['recommendation'] ?? null;

// Validate fields
if (
    empty($health_id) || empty($patient_name) || empty($medicine_id) || 
    empty($quantity) || empty($purpose) || empty($reason) || 
    empty($type_of_illness) || empty($disease) || empty($schedule)
) {
    echo "Error: All fields are required.";
    exit();
}

// Fetch medicine name and check availability in inventory
$selectMedicineQuery = "SELECT medicine_name, medicine_quantity FROM admin_medicine_inventory WHERE medicine_id = ?";
$stmtMedicine = $conn->prepare($selectMedicineQuery);
if (!$stmtMedicine) {
    error_log('Error preparing medicine query: ' . $conn->error);
    die('Error preparing medicine query: ' . $conn->error);
}
$stmtMedicine->bind_param("i", $medicine_id);
$stmtMedicine->execute();
$resultMedicine = $stmtMedicine->get_result();

if ($resultMedicine && $resultMedicine->num_rows > 0) {
    $rowMedicine = $resultMedicine->fetch_assoc();
    $medicine_name = $rowMedicine['medicine_name'];
    $currentQuantity = $rowMedicine['medicine_quantity'];

    if ($currentQuantity >= $quantity) {
        // Update the medicine inventory
        $updateMedicineQuery = "UPDATE admin_medicine_inventory SET medicine_quantity = medicine_quantity - ? WHERE medicine_id = ?";
        $stmtUpdate = $conn->prepare($updateMedicineQuery);
        if (!$stmtUpdate) {
            error_log('Error preparing inventory update query: ' . $conn->error);
            echo "Error: Could not prepare inventory update.";
            exit();
        }
        $stmtUpdate->bind_param("ii", $quantity, $medicine_id);
        if (!$stmtUpdate->execute()) {
            error_log('Error updating inventory: ' . $stmtUpdate->error);
            echo "Error: Could not update medicine inventory.";
            exit();
        }

        // Insert consultation record into the consultations table
        $insertConsultationQuery = "INSERT INTO consultations 
            (healthcare_id, patient_name, purpose, reason, type_of_illness, disease, 
            medicine_name, quantity, schedule, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')";

        $stmtInsert = $conn->prepare($insertConsultationQuery);
        if (!$stmtInsert) {
            error_log('Error preparing consultation insert query: ' . $conn->error);
            echo "Error: Could not prepare consultation insertion.";
            exit();
        }

        // Bind parameters
        $stmtInsert->bind_param(
            "issssssis",
            $health_id, $patient_name, $purpose, $reason, $type_of_illness, $disease, 
            $medicine_name, $quantity, $schedule
        );

        // Execute the query
        if ($stmtInsert->execute()) {
            echo "Consultation record saved successfully.";
        } else {
            error_log('Error inserting consultation: ' . $stmtInsert->error);
            echo "Error: Could not save the consultation. Error: " . $stmtInsert->error;
        }

        $stmtInsert->close();

    } else {
        echo "Error: Insufficient medicine quantity in inventory.";
    }
} else {
    echo "Error: Medicine not found in inventory.";
}

// Close database connections
$stmtMedicine->close();
$conn->close();
?>
