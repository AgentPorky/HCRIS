<?php
// Include database connection file
require 'db_conn.php';

// SQL query to fetch data only from the `consultations` table
$query = "
    SELECT 
        c.`consultation_id`, 
        c.`healthcare_id`, 
        c.`patient_id`, 
        c.`patient_name`, 
        c.`purpose` AS `consultation_purpose`, 
        c.`reason` AS `consultation_reason`, 
        c.`type_of_illness`, 
        c.`disease` AS `consultation_disease`, 
        c.`medicine_name`, 
        c.`quantity`, 
        c.`recommendation`, 
        c.`schedule` AS `consultation_schedule`, 
        c.`status`
    FROM `consultations` c
";

// Execute the query and fetch the result
$result = $conn->query($query);

// Check if the query was successful
if ($result) {
    // Check if there are rows returned
    if ($result->num_rows > 0) {
        // Initialize an array to store the data
        $data = [];
        
        // Fetch all rows and store them in the $data array
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        // Return the data in JSON format for easy use on the frontend
        echo json_encode($data);
    } else {
        // If no rows found, return an empty array (no need for additional message)
        echo json_encode([]);
    }
} else {
    // If the query failed, return an error message
    echo json_encode(["error" => "Query failed: " . $conn->error]);
}

// Close the database connection
$conn->close();
?>
