<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ths_healthcare"; // Corrected database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

// Fetch consultation and patient data
try {
    // Query for consultation counts by month and year (restricting to 2024-2026)
    $consultationQuery = "SELECT YEAR(schedule) AS year, MONTH(schedule) AS month, COUNT(*) AS consultations
                          FROM consultations
                          WHERE YEAR(schedule) BETWEEN 2024 AND 2026
                          GROUP BY year, month
                          ORDER BY year, month";

    $consultationResult = $conn->query($consultationQuery);

    // Check if the query was successful
    if (!$consultationResult) {
        throw new Exception("Error executing consultation query: " . $conn->error);
    }

    $consultations = [];
    while ($row = $consultationResult->fetch_assoc()) {
        // Format the month and year as "month/year" (e.g., "1/24")
        $formattedDate = $row["month"] . "/" . substr($row["year"], 2, 2);
        $consultations[] = [
            "date" => $formattedDate,
            "consultations" => (int)$row["consultations"]
        ];
    }

    // Query for patient counts by month and year (restricting to 2024-2026)
    $patientQuery = "SELECT YEAR(schedule) AS year, MONTH(schedule) AS month, COUNT(DISTINCT patient_id) AS patients
                     FROM consultations
                     WHERE YEAR(schedule) BETWEEN 2024 AND 2026
                     GROUP BY year, month
                     ORDER BY year, month";

    $patientResult = $conn->query($patientQuery);

    // Check if the query was successful
    if (!$patientResult) {
        throw new Exception("Error executing patient query: " . $conn->error);
    }

    $patients = [];
    while ($row = $patientResult->fetch_assoc()) {
        // Format the month and year as "month/year" (e.g., "1/24")
        $formattedDate = $row["month"] . "/" . substr($row["year"], 2, 2);
        $patients[] = [
            "date" => $formattedDate,
            "patients" => (int)$row["patients"]
        ];
    }

    // Combine data and send response
    echo json_encode([
        "consultations" => $consultations,
        "patients" => $patients
    ]);
} catch (Exception $e) {
    // Return the error message as JSON
    echo json_encode(["error" => $e->getMessage()]);
}

$conn->close();
?>
