<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../Css/adminhomepagestyles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>HCRIS ADMIN</title>
</head>
<body>

    <!-- Sidebar for navigation links -->
    <aside>
        <div id="sidenav" class="col-2">
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="adminhomepage.php" class="nav-link">
                        <i class="fa-solid fa-hospital me-2"></i>
                        <span class="d-none d-sm-inline text-white">DASHBOARD</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminconsultation.php" class="nav-link">
                        <i class="fa-solid fa-stethoscope me-2"></i>
                        <span class="d-none d-sm-inline text-white">Consultation</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="Appointments.php" class="nav-link">
                        <i class="fa-solid fa-users me-2"></i>
                        <span class="d-none d-sm-inline text-white">Appointments</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminmedicine.php" class="nav-link">
                        <i class="fa-solid fa-pills me-2"></i>
                        <span class="d-none d-sm-inline text-white">Medicine Inventory</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="healthcare_staff.php" class="nav-link">
                        <i class="fa-solid fa-user-nurse me-2"></i>
                        <span class="d-none d-sm-inline text-white">Healthcare Staff</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminpatientrec.php" class="nav-link">
                        <i class="fa-solid fa-user me-2"></i>
                        <span class="d-none d-sm-inline text-white">Patient Record</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminreport.php" class="nav-link">
                        <i class="fa-solid fa-chart-line me-2"></i>
                        <span class="d-none d-sm-inline text-white">Report</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminloginsessions.php" class="nav-link">
                        <i class="fa-solid fa-history me-2"></i>
                        <span class="d-none d-sm-inline text-white">Activity Log</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="fa-solid fa-plus me-2"></i>
                        <span class="d-none d-sm-inline text-white">Add Admin</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a id="signOutBtn" class="nav-link">
                        <i class="fa-solid fa-sign-out-alt me-2"></i>
                        <span class="d-none d-sm-inline text-white">Log Out</span>
                    </a>
                </li>
            </ul>
        </div>
    </aside>

    <!-- HEADER NAV BAR -->
    <header>
    <nav class="navbar navbar-expand-sm">
        <div class="logo-text-container">
            <div class="d-flex align-items-center">
                <img src="../Photos/logo.png" alt="Healthcare Logo" class="logo">
                <p class="logo-text text-white h3">Panghiawan Barangay Healthcare</p>
            </div>
            <p class="logo-text text-white h3 text-end">Welcome admin!</p>
        </div>
    </nav>
</header>

<!-- MAIN CONTENT OF THE HOME PAGE I PUT THE CONNECTION FIRST BECAUSE IF I PUT THE <MAIN> CONTENT IT CAUSES AN ERROR -->
    <?php

////////////////////////////// FOR PATIENT RECORD//////////////////////////////////////////////
// Include database connection file
require '../Admin/db_conn.php';

// Initialize $patient_count
$patient_count = 0;

// Check connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Query to count the number of patients using patient_id
$count_sql = "SELECT COUNT(patient_id) AS total_patients FROM patients";
$count_result = $conn->query($count_sql);

// Check if the query was successful
if ($count_result && $count_result->num_rows > 0) {
    $count_row = $count_result->fetch_assoc();
    $patient_count = $count_row['total_patients']; // Use the alias 'total_patients'
}

////////////////////// // FOR CONSULTATION RECORD !!///////////////////////////////////////////////////////////
// Initialize $consultation_count
$consultation_count = 0;

// Check connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Query to count the number of consultation using consultations_id
$count_sql = "SELECT COUNT(consultation_id) AS total_consultation FROM medical_record";
$count_result = $conn->query($count_sql);

// Check if the query was successful
if ($count_result && $count_result->num_rows > 0) {
    $count_row = $count_result->fetch_assoc();
    $consultation_count = $count_row['total_consultation']; // Use the alias 'total_consultation'
}

/////////////////////// FOR MEDICINE RECORDS //////////////////////////////////////
// Initialize $medicine_count
$medicine_count = 0;

// Check connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Query to count the number of medicine using medicine_id
$count_sql = "SELECT COUNT(medicine_id) AS total_medicine FROM admin_medicine_inventory";
$count_result = $conn->query($count_sql);

// Check if the query was successful
if ($count_result && $count_result->num_rows > 0) {
    $count_row = $count_result->fetch_assoc();
    $medicine_count = $count_row['total_medicine']; // Use the alias 'total_medicine'
}
?>

<main>
    <div class="container mt-5">
        <div class="row justify-content-center g-3">
            <!-- Card displaying the patient count -->
            <div class="col-md-4">
                <div class="card text-center border bg-success">
                    <div class="card-body">
                        <h5 class="card-title text-white">Total Patient</h5>
                        <p class="card-text fa-solid fa-user me-2 display-5 text-white"><?php echo $patient_count; ?></p>
                    </div>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="col-md-4">
                <div class="card text-center border bg-success">
                    <div class="card-body">
                        <h5 class="card-title text-white">Total Consultation</h5>
                        <p class="card-text fa-solid fa-stethoscope me-1 display-5 text-white"><?php echo $consultation_count; ?></p>
                    </div>
                </div>
            </div>
             <!-- Card 3 -->
             <div class="col-md-4 ">
                <div class="card text-center border bg-success">
                    <div class="card-body">
                        <h5 class="card-title text-white">Total Medicine</h5>
                        <p class="card-text fa-solid fa-pills me-2 display-5 text-white"><?php echo $medicine_count; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>


    <script>
        function toggleSidebar() {
            const sidenav = document.getElementById('sidenav');
            sidenav.classList.toggle('collapsed');
        }

        document.addEventListener('DOMContentLoaded', function () {
        // Ensure the DOM is fully loaded before running the script
        const logoutButton = document.querySelector('#signOutBtn');
        if (logoutButton) {
            logoutButton.addEventListener('click', function (e) {
                e.preventDefault(); // Prevent the default link action
                Swal.fire({
                    title: 'Are you sure?',
                    text: "Do you really want to sign out?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, sign out!',
                    cancelButtonText: 'No, stay logged in'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'logout.php'; // Adjust the URL to your logout script
                    }
                });
            });
        } else {
            console.error("Logout button (signOutBtn) not found!");
        }
    });

    </script>
</body>
</html>
