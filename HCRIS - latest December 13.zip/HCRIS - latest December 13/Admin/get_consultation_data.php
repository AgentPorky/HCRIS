<?php
// Include database connection file
require 'db_conn.php';


if (isset($_GET['id'])) {
    $_id = $_GET['id'];
    
    // Query to fetch consultation data by patient_id
    $query = "SELECT * FROM consultations WHERE patient_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode($result->fetch_assoc());
    } else {
        echo json_encode(null);  // No consultation found
    }
}
