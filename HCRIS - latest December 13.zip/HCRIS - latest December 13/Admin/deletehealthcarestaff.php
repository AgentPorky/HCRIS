<?php
// DATABASE CONNECTION
require 'db_conn.php';

header('Content-Type: application/json');

// Check if IDs are passed via POST
if (isset($_POST['ids']) && is_array($_POST['ids'])) {
    $ids = $_POST['ids'];

    // Prepare placeholders for the number of IDs
    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    // SQL query to delete the records
    $sql = "DELETE FROM admin_healthcare_unit WHERE healthcare_id IN ($placeholders)";

    // Prepare the statement
    if ($stmt = $conn->prepare($sql)) {
        // Bind the parameters dynamically
        $stmt->bind_param(str_repeat('s', count($ids)), ...$ids);

        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Healthcare staff(s) deleted successfully.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error deleting records: ' . $stmt->error]);
        }

        // Close the statement
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Error preparing statement: ' . $conn->error]);
    }
}

// Close the connection
$conn->close();
?>
