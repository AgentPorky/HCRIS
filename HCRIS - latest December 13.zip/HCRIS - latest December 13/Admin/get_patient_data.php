<?php
require 'db_conn.php';

if ($conn) {
    // Query to fetch patient names
    $patientQuery = "SELECT patient_name FROM patients_appointment";
    $patientResult = $conn->query($patientQuery);

    if ($patientResult) {
        if ($patientResult->num_rows > 0) {
            // Loop through each patient and generate an option element for each
            while ($patientRow = $patientResult->fetch_assoc()) {
                echo "<option value='" . htmlspecialchars($patientRow['patient_name'], ENT_QUOTES, 'UTF-8') . "'>"
                     . htmlspecialchars($patientRow['patient_name'], ENT_QUOTES, 'UTF-8') . "</option>";
            }
        } else {
            echo "<option disabled>No patients available</option>";
        }
    } else {
        echo "<option disabled>Error loading patients: " . $conn->error . "</option>";
    }
} else {
    echo "<option disabled>Connection error</option>";
}
?>
