<?php
session_start();
include "db_conn.php";

if (isset($_POST['uname']) && isset($_POST['password'])) {
    function validate($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    $uname = validate($_POST['uname']);
    $pass = validate($_POST['password']);

    if (empty($uname) || empty($pass)) {
        header("Location: Index.php?error=All fields are required");
        exit();
    } else {
        $hashedPass = md5($pass);

        $sql = "SELECT * FROM admin_register WHERE username = ? AND password = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $uname, $hashedPass);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            $_SESSION['admin_name'] = $row['name'];
            $_SESSION['admin_id'] = $row['user_id'];

            $adminName = $row['name'];
            $adminId = $row['user_id'];

            $insertLogin = "INSERT INTO admin_loginsessions (admin_name, admin_id, login_time) VALUES (?, ?, NOW())";
            $loginStmt = $conn->prepare($insertLogin);
            $loginStmt->bind_param("ss", $adminName, $adminId);
            $loginStmt->execute();

            header("Location: adminhomepage.php");
            exit();
        } else {
            header("Location: Index.php?error=Invalid username or password");
            exit();
        }
    }
}
?>
