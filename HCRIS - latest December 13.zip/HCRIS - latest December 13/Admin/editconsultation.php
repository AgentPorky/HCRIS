<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN_CONSULTATION</title>

    <!-- Bootstrap CSS for styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">
    
    <!-- Select2 CSS for searchable dropdowns -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/js/select2.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>

    <!-- DataTables CSS for table styling -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

</head>
<body>

    <!-- Edit Consultation Modal -->
    <div class="modal fade" id="editConsultationModal" tabindex="-1" aria-labelledby="editConsultationModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editConsultationModalLabel">Edit Consultation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editConsultationForm" method="post" action="update_consultation.php">
                        <!-- Hidden ID to identify which record to update -->
                        <input type="hidden" id="editConsultationId" name="consultation_id">

                        <!-- Healthcare staff Selection -->
                        <div class="mb-3">
                            <label for="edit_healthcare_id" class="form-label">Select staff:</label>
                            <select id="edit_healthcare_id" name="healthcare_id" required>
                                <option value="" disabled>Select staff</option>
                                <?php include 'get_healthcare_staff.php'; ?>
                            </select>
                        </div>
                        <!-- Patient Selection -->
                        <div class="mb-3">
                            <label for="edit_patient_name" class="form-label">Select Patient:</label>
                            <select id="edit_patient_name" name="patient_name" required>
                                <option value="" disabled>Select Patient</option>
                                <?php include 'get_patient_data.php'; ?>
                            </select>
                        </div>

                        <!-- Purpose -->
                        <div class="mb-3">
                            <label for="edit_purpose" class="form-label">Purpose:</label>
                            <input type="text" class="form-control" id="edit_purpose" name="purpose" required>
                        </div>

                        <!-- Reason -->
                        <div class="mb-3">
                            <label for="edit_reason" class="form-label">Reason:</label>
                            <input type="text" class="form-control" id="edit_reason" name="reason" required>
                        </div>

                        <!-- Type of Illness -->
                        <div class="mb-3">
                            <label for="edit_type_of_illness" class="form-label">Type of Illness:</label>
                            <input type="text" class="form-control" id="edit_type_of_illness" name="type_of_illness" required>
                        </div>

                        <!-- Disease -->
                        <div class="mb-3">
                            <label for="edit_disease" class="form-label">Disease:</label>
                            <input type="text" class="form-control" id="edit_disease" name="disease" required>
                        </div>

                        <!-- Medicine Selection -->
                        <div class="mb-3">
                            <label for="edit_medicine_id" class="form-label">Select Medicine:</label>
                            <select id="edit_medicine_id" name="medicine_id" required>
                                <option value="" disabled>Select Medicine</option>
                                <?php include 'get_medicine_select.php'; ?>
                            </select>
                        </div>

                        <!-- Medicine Quantity -->
                        <div class="mb-3">
                            <label for="edit_quantity" class="form-label">Quantity:</label>
                            <input type="number" class="form-control" id="edit_quantity" name="quantity" required>
                        </div>

                        <!-- Recommendation -->
                        <div class="mb-3">
                            <label for="edit_recommendation" class="form-label">Recommendation:</label>
                            <textarea class="form-control" id="edit_recommendation" name="recommendation"></textarea>
                        </div>

                        <!-- Schedule -->
                        <div class="mb-3">
                            <label for="edit_schedule" class="form-label">Schedule:</label>
                            <input type="datetime-local" class="form-control" id="edit_schedule" name="schedule" required>
                        </div>

                        <!-- Submit Button -->
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Consultation Table -->
    <div class="container table-container">
        <table id="consultationTable" class="display table table-striped table-hover table-bordered" style="width:100%;">
            <thead>
                <tr>
                    <th>Select</th>
                    <th>Fullname</th>
                    <th>Purpose</th>
                    <th>Reason</th>
                    <th>Type of Illness</th>
                    <th>Disease</th>
                    <th>Medicine Name</th>
                    <th>Quantity</th>
                    <th>Recommendations</th>
                    <th>Schedule</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="tableBody">
                <!-- Dynamic rows will be populated here -->
            </tbody>
        </table>
    </div>

    <!-- Fetch and display data (You may replace this with your own PHP script) -->
    <script>
        fetch('get_consultation_and_patient_data.php')
            .then(response => response.json())
            .then(data => {
                const tableBody = document.querySelector('#tableBody');
                tableBody.innerHTML = ''; // Clear any previous data

                if (Array.isArray(data) && data.length > 0) {
                    data.forEach(row => {
                        const tableRow = document.createElement('tr');
                        tableRow.innerHTML = `
                            <td><input type="checkbox" class="row-checkbox" value="${row.consultation_id}"></td>
                            <td>${row.patient_name}</td>
                            <td>${row.consultation_purpose}</td>
                            <td>${row.consultation_reason}</td>
                            <td>${row.type_of_illness}</td>
                            <td>${row.consultation_disease}</td>
                            <td>${row.medicine_name}</td>
                            <td>${row.quantity}</td>
                            <td>${row.recommendation}</td>
                            <td>${row.consultation_schedule}</td>
                            <td>${row.status}</td>
                            <td>
                                <button class="btn btn-warning btn-sm edit-btn" data-id="${row.consultation_id}">Edit</button>
                            </td>
                        `;
                        tableBody.appendChild(tableRow);
                    });
                }

                // Handle Edit Button Click
                document.querySelectorAll('.edit-btn').forEach(button => {
                    button.addEventListener('click', function() {
                        const consultationId = this.getAttribute('data-id');

                        // Fetch and populate the edit modal form with data
                        fetch(`get_consultation_details.php?id=${consultationId}`)
                            .then(response => response.json())
                            .then(data => {
                                if (data) {
                                    // Populate the modal fields
                                    document.getElementById('editConsultationId').value = data.consultation_id;
                                    document.getElementById('edit_healthcare_id').value = data.healthcare_id;
                                    document.getElementById('edit_patient_name').value = data.patient_name;
                                    document.getElementById('edit_purpose').value = data.consultation_purpose;
                                    document.getElementById('edit_reason').value = data.consultation_reason;
                                    document.getElementById('edit_type_of_illness').value = data.type_of_illness;
                                    document.getElementById('edit_disease').value = data.consultation_disease;
                                    document.getElementById('edit_medicine_id').value = data.medicine_id;
                                    document.getElementById('edit_quantity').value = data.quantity;
                                    document.getElementById('edit_recommendation').value = data.recommendation;
                                    document.getElementById('edit_schedule').value = data.consultation_schedule;

                                    // Show the modal
                                    new bootstrap.Modal(document.getElementById('editConsultationModal')).show();
                                }
                            });
                    });
                });
            });
    </script>

</body>
</html>
