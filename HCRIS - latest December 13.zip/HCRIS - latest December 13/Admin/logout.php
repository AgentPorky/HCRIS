<?php
session_start();
include "db_conn.php";

if (isset($_SESSION['admin_name']) && isset($_SESSION['admin_id'])) {
    $adminName = $_SESSION['admin_name'];
    $adminId = $_SESSION['admin_id'];

    $insertLogout = "INSERT INTO adminlogoutsessions (admin_name, admin_id, logout_time) VALUES (?, ?, NOW())";
    $logoutStmt = $conn->prepare($insertLogout);
    $logoutStmt->bind_param("ss", $adminName, $adminId);
    $logoutStmt->execute();
}

// Destroy the session
session_unset();
session_destroy();

header("Location: Index.php");
exit();
?>
