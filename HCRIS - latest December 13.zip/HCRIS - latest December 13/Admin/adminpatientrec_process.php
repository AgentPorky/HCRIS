<?php
// Include your database connection file (make sure 'db_conn.php' is correct)
require 'db_conn.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Sanitize and retrieve form data
    $patient_name = mysqli_real_escape_string($conn, $_POST['patient_name']);
    $patient_email = mysqli_real_escape_string($conn, $_POST['patient_email']);
    $patient_phone = mysqli_real_escape_string($conn, $_POST['patient_phone']);
    $patient_address = mysqli_real_escape_string($conn, $_POST['patient_address']);

    try {
        // Insert patient data into the database
        $query = "INSERT INTO patients (name, email, phone, address) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);

        if (!$stmt) {
            throw new Exception("Failed to prepare the SQL statement: " . $conn->error);
        }

        // Bind parameters (assuming all values are strings)
        $stmt->bind_param('ssss', $patient_name, $patient_email, $patient_phone, $patient_address);

        // Execute the statement
        if ($stmt->execute()) {
            // Successfully registered patient, show alert and redirect
            echo "<script type='text/javascript'>
                    alert('Thank you for registering!');
                    window.location.href = 'adminpatientrec.php';
                  </script>";
        } else {
            throw new Exception("Failed to register patient: " . $stmt->error);
        }

        // Close statement
        $stmt->close();

    } catch (Exception $e) {
        // If an error occurs, show an error message
        echo "Error: " . $e->getMessage();
    }
}

